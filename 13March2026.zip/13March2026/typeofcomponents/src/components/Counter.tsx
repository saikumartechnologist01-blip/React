"use client"

import { useReducer } from "react"
import { counterReducer } from "@/reducers/counterReducer"

export default function Counter() {
  const [count, dispatch] = useReducer(counterReducer, 0)

  return (
    <div>
      <h2>Count: {count}</h2>

      <button onClick={() => dispatch({ type: "increment" })}>
        Increment
      </button> <br></br><br></br>

      <button onClick={() => dispatch({ type: "decrement" })}>
        Decrement
      </button><br></br><br></br>

      <button onClick={() => dispatch({ type: "reset" })}>
        Reset
      </button>
    </div>
  )
}
