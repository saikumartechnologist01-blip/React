export type CounterAction =
  | { type: "increment" }
  | { type: "decrement" }
  | { type: "reset" }

export function counterReducer(state: number, action: CounterAction): number {
    console.log("Reducer called with state:", state, "and action:", action)
  switch (action.type) {
    case "increment":
      return state + 1

    case "decrement":
      return state - 1

    case "reset":
      return 0

    default:
      return state
  }
}
