"use client"

import { useEffect, useState } from "react"

export default function Products() {
  const [products, setProducts] = useState([])

  useEffect(() => {
    fetch("https://fakestoreapi.com/products")
      .then(res => res.json())
      .then(data => setProducts(data))
  }, [])

  return (
    <div>
      {products.map((p: any) => (
        <p key={p.id}>{p.title}</p>
      ))}
    </div>
  )
}
