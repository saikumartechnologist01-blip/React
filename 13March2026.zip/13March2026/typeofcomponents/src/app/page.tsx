import Counter from "@/components/Counter"


export default function Home() {
  return (
    <main>
      <h1>useReducer Counter Example</h1>
      <Counter />
     
    </main>
  )
}
