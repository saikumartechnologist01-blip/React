var products = [
   {
    pid:101, 
    name:"product 1"
   },
   {
    pid:102, 
    name:"product 2"
   },
   {
    pid:103, 
    name:"product 3"
   },
    {
    pid:103, 
    name:"product 3"
   },
   {
    pid:102, 
    name:"product 2"
   }

]
products.forEach(product => console.log(product.pid + "\t" + product.name))




