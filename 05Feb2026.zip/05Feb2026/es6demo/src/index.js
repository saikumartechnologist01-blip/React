
  async function fetchUsers(){
    try{
 const response = await fetch("https://fakestoreapi.com/users?limit=5",
    {
        method:"GET",
        headers:{
            "Content-Type":"application/json",
            "token": "abcfkfh"
        }
    }
 );
      const finalResponse = await response.json();
      console.log("Final response:",finalResponse)
    }
    catch(error){
        console.log(error);
    } 
    console.log("after fetch"); 
  }
  fetchUsers();



  