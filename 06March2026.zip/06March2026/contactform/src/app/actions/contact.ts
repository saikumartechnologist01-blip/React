'use server'

import { prisma } from '@/lib/prisma'

export async function submitContact(formData: FormData) {

  const name = formData.get('name') as string
  const email = formData.get('email') as string
  const message = formData.get('message') as string

  // Simple validation
  if (!name || !email || !message) {
    return { error: "All fields are required" }
  }

  await prisma.contact.create({
    data: {
      name,
      email,
      message
    }
  })

  return { success: true }
}