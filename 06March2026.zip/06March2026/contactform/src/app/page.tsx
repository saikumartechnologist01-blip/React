'use client'

import React from "react"
import { submitContact } from "./actions/contact"

export default function Home() {

  const [message, setMessage] = React.useState("")

  async function handleSubmit(formData: FormData) {

    const result = await submitContact(formData)

    if (result?.error) {
      setMessage(result.error)
    }

    if (result?.success) {
      setMessage("Message sent successfully!")
    }
  }

  return (
    <div style={{padding: "40px"}}>

      <h1>Contact Us</h1>

      <form action={handleSubmit} style={{display:"flex",flexDirection:"column",gap:"10px",maxWidth:"400px"}}>

        <input name="name" placeholder="Name" />

        <input name="email" placeholder="Email" />

        <textarea name="message" placeholder="Message"></textarea>

        <button type="submit">Send Message</button>

      </form>

      {message && <p>{message}</p>}

    </div>
  )
}