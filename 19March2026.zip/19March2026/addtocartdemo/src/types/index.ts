export interface Product {
  id: number;
  title: string;
  price: number;
  description: string;
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export type CartAction =
  | { type: "ADD_TO_CART"; payload: Product };