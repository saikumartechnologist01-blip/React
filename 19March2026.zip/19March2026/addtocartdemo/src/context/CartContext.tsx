"use client";

import { createContext, useReducer, ReactNode } from "react";
import { cartReducer } from "../reducers/cartReducer";
import { CartItem, CartAction } from "../types";

interface CartContextType {
  cart: CartItem[];
  dispatch: React.Dispatch<CartAction>;
}

export const CartContext = createContext<CartContextType | null>(null);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [cart, dispatch] = useReducer(cartReducer, []);

  return (
    <CartContext.Provider value={{ cart, dispatch }}>
      {children}
    </CartContext.Provider>
  );
};