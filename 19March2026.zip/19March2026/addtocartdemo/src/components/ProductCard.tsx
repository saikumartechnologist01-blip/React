"use client";

import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import { Product } from "../types";

export default function ProductCard({ product }: { product: Product }) {
  const context = useContext(CartContext);
  if (!context) throw new Error("CartContext not found");

  const { dispatch } = context;

  return (
    <div className="product-card">
      <img
        src={product.image}
        alt={product.title}
        style={{ height: "150px", objectFit: "contain", width: "100%" }}
      />

      <h2 style={{ fontWeight: "600", marginTop: "10px" }}>
        {product.title}
      </h2>

      <p style={{ fontSize: "14px", color: "#555" }}>
        {product.description.slice(0, 80)}...
      </p>

      <p style={{ fontWeight: "bold", marginTop: "10px" }}>
        ${product.price}
      </p>

      <button
        onClick={() =>
          dispatch({ type: "ADD_TO_CART", payload: product })
        }
        style={{
          marginTop: "12px",
          padding: "8px 12px",
          backgroundColor: "black",
          color: "white",
          borderRadius: "8px",
          cursor: "pointer",
          border: "none",
        }}
      >
        Add to Cart
      </button>
    </div>
  );
}