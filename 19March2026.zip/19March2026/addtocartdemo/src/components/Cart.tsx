"use client";

import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function Cart() {
  const context = useContext(CartContext);
  if (!context) throw new Error("CartContext not found");

  const { cart } = context;

  return (
    <div style={{ marginTop: "30px" }}>
      <h2 style={{ fontSize: "20px", fontWeight: "bold" }}>Cart</h2>

      {cart.length === 0 ? (
        <p>Cart is empty</p>
      ) : (
        <div style={{ marginTop: "10px" }}>
          {cart.map((item) => (
            <div
              key={item.id}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                border: "1px solid #ddd",
                padding: "10px",
                borderRadius: "10px",
                marginBottom: "10px",
                gap: "10px",
              }}
            >
              {/* LEFT: IMAGE */}
              <img
                src={item.image}
                alt={item.title}
                style={{ width: "60px", height: "60px", objectFit: "contain" }}
              />

              {/* MIDDLE: DETAILS */}
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 600 }}>{item.title}</p>
                <p style={{ fontSize: "14px", color: "#555" }}>
                  ${item.price} × {item.quantity}
                </p>
              </div>

              {/* RIGHT: TOTAL */}
              <div style={{ fontWeight: "bold" }}>
                ${(item.price * item.quantity).toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}