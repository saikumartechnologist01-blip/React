
import type React from "react";
import type { ReactNode } from "react";

type BoxProps = {
  children: ReactNode;
};

const Box = ({children}:BoxProps) =>{

    return (
        <div style={{border: "1px solid red"}}>
            {children}
        </div>
    )
}
export default Box;