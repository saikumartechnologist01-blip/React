import { useEffect, useState } from "react";

const Product = () =>{

    const [products,setProducts] = useState([]);


     useEffect( () => {
      
        const fetchUsers = async () => {
             const response =  await fetch("https://fakestoreapi.com/products");
             const productsData =  await response.json();
             console.log(productsData);
             setProducts(productsData);
        }
        fetchUsers();
        
     },[]);

    return (
        <div>
             <h1>Products</h1>
 
              {products.length}
            
        </div>
    )
}
export default Product;