import { useState } from 'react'

import './App.css'
import Product from './Product'
import Box from './Box'
import Header from './Header'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     
      <h1>App Component!</h1>
      {/* <Product></Product> */}


      <Header>
           <h1>Header Content Here</h1>
      </Header>
        
    </>
  )
}

export default App
