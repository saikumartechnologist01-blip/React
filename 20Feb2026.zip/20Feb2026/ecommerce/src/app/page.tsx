

export default function Home() {
  console.log("This is the home page of the application");
  return (
    <div>
       <h1> This is the home page of the application</h1>
    </div>
  );
}
