
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>

             

         <div style={ {border: "1px solid red", padding: "10px"}}>

              <a href="/">Home</a>
              <a href="/about">About</a>

                {children}
         </div>
        
      </body>
    </html>
  );
}
