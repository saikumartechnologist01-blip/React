import "./globals.css";
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
          <a href="/login">Login</a>
          <a href="/register">Register</a>
          <a href="/contact">Contact</a>
        {children}
      </body>
    </html>
  );
}
