export default function AboutLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
         <div style={ {border: "1px solid orange", padding: "10px"}}>
                {children}
         </div>
      </body>
    </html>
  );
}
