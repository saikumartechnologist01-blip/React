

export default function Team() {
  return (
    <div>
       <h1> This is the team page of the application</h1>
    </div>
  );
}
