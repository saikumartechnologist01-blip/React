import './login.css';
const Login = () =>{
    return(
         <div className="container">
      <div className="card">
        <h1 className="logo">ERP Dashboard</h1>
        <p className="tagline">Enterprise Resource Planning System</p>

        <form>
          <div className="inputGroup">
            <label>Email</label>
            <input
              type="email"
              placeholder="Enter your email"
            />
          </div>

          <div className="inputGroup">
            <label>Password</label>
            <input
              type="password"
              placeholder="Enter your password"
              required
            />
          </div>

          <button type="submit">Login</button>
        </form>

        <p className="footer">
          Forgot password? <span>Reset</span>
        </p>
      </div>
      </div>
    )
}
export default Login;