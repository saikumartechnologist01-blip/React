"use client";

import { useState } from "react";
const  Contact= () => {
     const [count, setCount] = useState(0);
  console.log("This is the contact page of the application");
  return (
    <div>
        <h1>The counter value is {count}</h1>
        <button onClick={() => setCount(count + 1)}>Increment</button>

    </div>
  );
}
export default Contact;
