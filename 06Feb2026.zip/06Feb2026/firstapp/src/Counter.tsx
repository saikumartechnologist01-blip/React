import { useState } from "react";


const Counter = () => {
    
     const [count, updateCount] = useState(0); // we maintain data in the state.

      const incrementValue = () =>{
                 updateCount(count + 1);
       }

       const decrementValue = () =>{
                 updateCount(count - 1);
       }

     return(
        <div>
              <h1>Count : {count}</h1>

               <button onClick={incrementValue}>Increment</button>
                <button onClick={decrementValue}>Decrement</button>
        </div>
     )

}

export default Counter;


// Component -> data gets maintained in the state. 

