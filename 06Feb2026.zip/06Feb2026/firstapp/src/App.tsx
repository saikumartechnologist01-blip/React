
// First Component 

import Counter from "./Counter";


const App = () => {

  return (<div>
             <h1>My First App</h1> 
             {/* <Navbar></Navbar> */}
              <Counter></Counter>
  </div>)

}

export default App;


// Login component and use it in App Component.