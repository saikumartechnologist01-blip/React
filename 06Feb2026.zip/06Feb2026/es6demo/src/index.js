
  var x=100; 

  console.log(typeof x); // number

  x = "Hello World";

  console.log(typeof x); // string