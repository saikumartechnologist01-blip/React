
interface User{
    name: string;
    age: number;
}


function generateUserInformation(username:string,age:number):User{
    return {
        name: username,
        age: age
    };
}

console.log(generateUserInformation("John Doe", 30));