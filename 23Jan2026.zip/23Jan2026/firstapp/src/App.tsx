
import './App.css'
import Login from './Login'

function App() {

  return (
    <>
      <div>
         <h1>This is my first app using React</h1>
          <Login></Login>
      </div>
      
    </>
  )
}

export default App
