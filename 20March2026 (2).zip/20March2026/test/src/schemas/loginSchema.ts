import { z } from "zod";

export const loginSchema = z.object({
  email: z.string().email("Invalid email"),
  password: z.string().min(6, "Min 6 characters")
  .regex(/[A-Z]/, "Must contain an uppercase letter")
  .regex(/[a-z]/, "Must contain a lowercase letter")
  .regex(/\d/, "Must contain a number")
  .regex(/[@$!%*?&]/, "Must contain a special character"),
  otp: z.string().min(6, "Min 6 characters").max(6, "Max 6 characters"),
 
});



// Criteria:   .com, .in. org, .net, .edu, .gov, .io, .co, .us, .uk, .ca, .au, .de, .fr, .jp, .cn, .br, .ru, .ch, .it, .nl, .se, .no, .es, .mil 


// advanced validation: 