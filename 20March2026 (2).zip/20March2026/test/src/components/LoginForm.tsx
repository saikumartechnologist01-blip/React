"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema } from "../schemas/loginSchema";
import { z } from "zod";

// infer TypeScript type from schema
type LoginFormData = z.infer<typeof loginSchema>;

export default function LoginForm() {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFormData) => {
    console.log("Valid Data:", data);

    // simulate API call
    await new Promise((res) => setTimeout(res, 1000));
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>

      {/* EMAIL */}
      <div>
        <input
          type="email"
          placeholder="Enter email"
          {...register("email")}
        />
        <p style={{ color: "red" }}>
          {errors.email?.message}
        </p>
      </div>

      {/* PASSWORD */}
      <div>
        <input
          type="password"
          placeholder="Enter password"
          {...register("password")}
        />
        <p style={{ color: "red" }}>
          {errors.password?.message}
        </p>
      </div>

        {/* PASSWORD */}
      <div>
        <input
          type="text"
          placeholder="Enter OTP"
          {...register("otp")}
        />
        <p style={{ color: "red" }}>
          {errors.otp?.message}
        </p>
      </div>

      <button type="submit" disabled={isSubmitting}>
        {isSubmitting ? "Logging in..." : "Login"}
      </button>
    </form>
  );
}