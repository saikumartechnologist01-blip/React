"use client"

import { useTheme } from "@/context/useTheme"

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme()

     const switcher = () =>{
      if(theme === "light"){
        setTheme("dark")
      }
      else{        setTheme("light")
      }
     }

  return (
    <div>
      <p>Current theme: {theme}</p>

      <button onClick={switcher}>
        Switch Theme
      </button>
    </div>
  )
}