type ThemeContextType = {
  theme: string
  setTheme: (theme: string) => void
}

import { createContext } from "react"

export const ThemeContext = createContext<ThemeContextType | undefined>(undefined)