"use client"

import { useState, ReactNode } from "react"
import { ThemeContext } from "./ThemeContext"

type Props = {
  children: ReactNode
}



export default function ThemeProvider({ children }: Props) {
  const [theme, setTheme] = useState("light")

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

