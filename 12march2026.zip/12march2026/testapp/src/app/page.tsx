import ThemeSwitcher from "@/components/ThemeSwitcher";


export default function Page() {
  return (
    <main>
      <h1>Context API Demo</h1>
      
      <ThemeSwitcher />
    </main>
  )
}