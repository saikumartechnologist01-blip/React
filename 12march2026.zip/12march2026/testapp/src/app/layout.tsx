import ThemeProvider from "@/context/ThemeProvider"

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html>
      <body>
         <a href="/login">Login</a>
        <ThemeProvider>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}