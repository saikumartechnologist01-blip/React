"use client"

import { useTheme } from "@/context/useTheme"

export default function Login() {

      const { theme, setTheme } = useTheme();

    return (
        <div>
            <h1>Login Page</h1>
            <p>Current theme: {theme}</p>
        </div>
    )

}
