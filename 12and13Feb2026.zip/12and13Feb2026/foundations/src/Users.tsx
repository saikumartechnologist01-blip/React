import React from 'react';


interface UserInfo{
    user: {
        name: string;
        role: string;
    }
}

 const Users:React.FC<UserInfo> = ({user}) => {



             console.log(user.name, user.role);

    return (
         <>
            <h1>User Information</h1>
            <p>Name : {user.name}</p>
            <p>Role : {user.role}</p>

         </>
    )
}
export default Users;