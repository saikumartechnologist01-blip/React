import type { ReactNode } from "react";
import "./Layout.css";
type LayoutProps = {
    header:ReactNode, navbar:ReactNode, children:ReactNode
}

function Layout({ header, navbar, children }:LayoutProps) {
  return (
    <div>
      <header className="header">{header}</header>
      <aside className="sidebar">{navbar}</aside>
      <main className="content">{children}</main>
    </div>
  );
}

export default Layout;