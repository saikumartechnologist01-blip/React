import { useRef } from "react";



const UnControlled = () => {

     const inputRef=useRef<HTMLInputElement>(null);
     const handleSubmit= () =>{
           
         if(inputRef.current != null){
            console.log(inputRef.current.value);
         }
     }


    return ( <div>
          <h1>UnControlled Component</h1>

           <input type="text" ref={inputRef} /> <br></br>
              <button onClick={handleSubmit}>Show Value</button>
    </div>)
}

export default UnControlled;