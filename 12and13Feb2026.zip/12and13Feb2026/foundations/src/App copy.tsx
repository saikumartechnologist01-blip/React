
import './App.css'
import Box from './Box'
import Controlled from './Controlled'
import Login from './Login'
import Products from './Products'
import UnControlled from './UnControlled'
import UserHome from './UserHome'
import Users from './Users'

function App() {

  const isUserLoggedIn = false;
 
   const user = {
      name: "Sai Kumar",
      role: "Software Engineer",
     
   }
  return (
    <>
      
      {/* <h1>App Component</h1>
       <Users user={user}></Users>
       <Products></Products>
    
    {isUserLoggedIn ? <UserHome></UserHome> : <Login></Login>}

     <Controlled></Controlled>
     <UnControlled></UnControlled> */}

     {/* <Box>
          <h2>Hello</h2>
          <h3>Hey</h3>
     </Box> */}

     


       
    </>
  )
}

export default App

// if user is "regular user" -> "RegularUser"  "previliged user" -> "PriviledgedUser"  "
