import { useState } from "react"

const Controlled = () => {

     const [value, setValue] = useState("");

     return(

        <div>
        <input
            type="text"
            value ={value}
            onChange ={(e) => setValue(e.target.value)}
        /> <br></br>
        Value : {value}
        </div>
     )

}

export default Controlled