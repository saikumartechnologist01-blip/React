
import './App.css'
import Content from './Content'
import Header from './Header'
import Layout from './Layout'
import Navbar from './Navbar'

function App() {

  return (
    <>
      
      
      <Layout  header={<Header></Header>} navbar={<Navbar></Navbar>}>

            <Content></Content>

      </Layout>
     


       
    </>
  )
}

export default App

// if user is "regular user" -> "RegularUser"  "previliged user" -> "PriviledgedUser"  "
