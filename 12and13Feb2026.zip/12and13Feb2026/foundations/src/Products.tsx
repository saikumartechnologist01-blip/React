
const Products = () => {
    const products = [
        { id: 1, name: "Laptop", price: 999 },
        { id: 2, name: "Smartphone", price: 499 },
        { id: 3, name: "Headphones", price: 199 },
    ];

     const iterate = () =>{
        return products.map((product) => {
            return <li key={product.id}>{product.id} {product.name} {product.price}</li>
        })
     }
    return (
        <div>
            <h1>Product List</h1>

             <ul>
                {iterate()}
             </ul>
         </div>
    )
}
export default Products;
// Iterate a list of users and display their information in the UI.
